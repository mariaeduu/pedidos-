﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/

CKEDITOR.plugins.setLang('placeholder','fr',{placeholder:{title:"Propriétés de l'Espace réservé",toolbar:"Créer l'Espace réservé",text:"Texte de l'Espace réservé",edit:"Modifier l'Espace réservé",textMissing:"L'Espace réservé doit contenir du texte."}});
